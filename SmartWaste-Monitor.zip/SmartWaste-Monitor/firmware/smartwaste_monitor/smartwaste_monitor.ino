// SmartWaste Monitor - ESP32 + HC-SR04 smart dustbin node
#include <WiFi.h>
#include <HTTPClient.h>
#include "secrets.h"

#define TRIG 5
#define ECHO 18
#define RED 26
#define GREEN 25
#define BUZZER 27

const char*  BIN_ID       = "BIN-01";      // unique per bin
const char*  BIN_LOCATION = "Canteen_entrance";
const float  BIN_HEIGHT   = 40.0;          // cm, sensor to bottom
const int    THRESHOLD    = 80;            // percent
const unsigned long INTERVAL = 60000;      // ms
bool alerted = false;                      // avoid repeat alerts until emptied

float readDistance() {
  digitalWrite(TRIG, LOW);  delayMicroseconds(2);
  digitalWrite(TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG, LOW);
  long t = pulseIn(ECHO, HIGH, 30000);
  if (t == 0) return BIN_HEIGHT;           // no echo -> treat as empty
  return (t * 0.0343) / 2.0;
}

int fillPercent() {                         // median of 5 readings
  float r[5];
  for (int i = 0; i < 5; i++) { r[i] = readDistance(); delay(50); }
  for (int i = 0; i < 4; i++) for (int j = i + 1; j < 5; j++)
    if (r[j] < r[i]) { float x = r[i]; r[i] = r[j]; r[j] = x; }
  int p = (int)(((BIN_HEIGHT - r[2]) / BIN_HEIGHT) * 100);
  return constrain(p, 0, 100);
}

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  for (int i = 0; i < 20 && WiFi.status() != WL_CONNECTED; i++) delay(500);
}

void sendToCloud(int fill, bool full) {
  if (WiFi.status() != WL_CONNECTED) return;
  HTTPClient http;
  String url = String("http://api.thingspeak.com/update?api_key=") + TS_API_KEY +
               "&field1=" + fill + "&field2=" + (full ? 1 : 0) +
               "&status=" + BIN_ID + "_" + BIN_LOCATION;
  http.begin(url); http.GET(); http.end();
}

void sendTelegramAlert(int fill) {
  if (WiFi.status() != WL_CONNECTED) return;
  HTTPClient http;
  String msg = String(BIN_ID) + " at " + BIN_LOCATION + " is " + fill + "%25 full - collect now";
  String url = String("https://api.telegram.org/bot") + TG_BOT_TOKEN +
               "/sendMessage?chat_id=" + TG_CHAT_ID + "&text=" + msg;
  http.begin(url); http.GET(); http.end();
}

void setup() {
  Serial.begin(115200);
  pinMode(TRIG, OUTPUT); pinMode(ECHO, INPUT);
  pinMode(RED, OUTPUT); pinMode(GREEN, OUTPUT); pinMode(BUZZER, OUTPUT);
  connectWiFi();
}

void loop() {
  connectWiFi();                            // auto-reconnect
  int fill = fillPercent();
  bool full = fill >= THRESHOLD;
  digitalWrite(RED, full); digitalWrite(GREEN, !full); digitalWrite(BUZZER, full);
  Serial.printf("%s fill=%d%%\n", BIN_ID, fill);
  sendToCloud(fill, full);
  if (full && !alerted) { sendTelegramAlert(fill); alerted = true; }
  if (!full) alerted = false;
  delay(INTERVAL);
}
