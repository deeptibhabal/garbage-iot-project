(() => {
  const THRESHOLD = 80;
  const bins = [
    {id:'BIN-01', loc:'Canteen entrance', fill:62, rate:2.4},
    {id:'BIN-02', loc:'Main road gate',   fill:35, rate:1.8},
    {id:'BIN-03', loc:'Library corridor', fill:12, rate:0.7},
    {id:'BIN-04', loc:'Parking area',     fill:48, rate:1.2},
  ];
  const wrap = document.getElementById('bins'), logEl = document.getElementById('log');
  let logged = 0;
  const stamp = () => new Date().toLocaleTimeString();

  function render() {
    wrap.innerHTML = '';
    bins.forEach((b, i) => {
      const full = b.fill >= THRESHOLD;
      const c = document.createElement('div');
      c.className = 'card' + (full ? ' full' : '');
      c.innerHTML = `<b>${b.id}</b><span>${b.loc}</span><div class="pct">${Math.round(b.fill)}%</div>
        <div class="bar"><i style="width:${b.fill}%"></i></div>
        <div class="status">${full ? 'FULL – collect now' : 'Normal'}</div>
        <span>Updated ${b.t || stamp()}</span>`;
      const btn = document.createElement('button');
      btn.textContent = 'Collected'; btn.disabled = !full; btn.style.marginTop = '8px';
      btn.onclick = () => collect(i);
      c.appendChild(btn); wrap.appendChild(c);
    });
  }
  function collect(i) {
    const b = bins[i];
    if (!logged) logEl.innerHTML = '';
    logged++;
    const li = document.createElement('li');
    li.textContent = `${stamp()} – ${b.id} (${b.loc}) emptied at ${Math.round(b.fill)}%`;
    logEl.prepend(li); b.fill = 2;
    render();
  }
  setInterval(() => {
    bins.forEach(b => { b.fill = Math.min(100, b.fill + b.rate * (0.5 + Math.random())); b.t = stamp(); });
    render();
  }, 2000);
  render();

  const H = document.getElementById('H'), d = document.getElementById('d'), res = document.getElementById('res');
  function calc() {
    const h = +H.value, dist = +d.value;
    if (!(h > 0) || dist < 0) { res.textContent = 'Enter valid values'; return; }
    const p = Math.max(0, Math.min(100, Math.round((h - dist) / h * 100)));
    res.textContent = `Fill: ${p}% – ${p >= THRESHOLD ? 'ALERT: collect now' : 'OK'}`;
    res.style.color = p >= THRESHOLD ? 'var(--warn)' : 'var(--ac)';
  }
  H.oninput = d.oninput = calc; calc();
})();
