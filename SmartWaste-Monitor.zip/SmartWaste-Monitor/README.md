# ♻ SmartWaste Monitor

IoT-based smart dustbin monitoring and notification system for efficient waste collection.
Community Engagement Project, B.E. Computer Engineering (SPPU), 2026–27.

An ESP32 + HC-SR04 ultrasonic sensor measures a bin's fill level, shows status on LEDs/buzzer, uploads readings to ThingSpeak, and sends a Telegram alert when the bin reaches **80%**.

## Repository structure
```
index.html, style.css, script.js   Project website (static, with simulated dashboard demo)
assets/                            Figures from the report
firmware/smartwaste_monitor/       ESP32 Arduino sketch
docs/                              Full project report (.docx)
.github/workflows/pages.yml        Auto-deploy website to GitHub Pages
```

## Website
Open `index.html` locally, or publish with GitHub Pages: **Settings → Pages → Source: GitHub Actions**. Push to `main` and the site deploys.

## Firmware setup
1. Install Arduino IDE + the **ESP32** board package.
2. Copy `firmware/smartwaste_monitor/secrets.h.example` to `secrets.h` and fill in Wi-Fi, ThingSpeak write key, Telegram bot token and chat ID.
3. Set `BIN_ID`, `BIN_LOCATION` and `BIN_HEIGHT` (cm) in the sketch.
4. Select **ESP32 Dev Module**, upload, and open the Serial Monitor at 115200 baud.
5. ThingSpeak channel: field1 = fill %, field2 = alert flag.

## Wiring
| Device | ESP32 |
|---|---|
| HC-SR04 VCC / GND | VIN / GND |
| Trig | GPIO5 |
| Echo | GPIO18 (via 1k/2k divider) |
| Red LED / Green LED / Buzzer | GPIO26 / GPIO25 / GPIO27 |

Fill % = ((H − d) / H) × 100, using the median of 5 readings.

## Team
Deepti Bhabal (SCOA01) · Akshra Rampure (SCOA12) · Aditi Balwe (SCOA14) · Aaina Mahajan (SCOA19)
Guide: Dr. Chaya Jadhav

## License
MIT
